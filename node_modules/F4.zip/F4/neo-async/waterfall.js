'use strict';

module.exports = require('./async').waterfall;
